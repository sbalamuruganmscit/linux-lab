package com.example.demobala;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoBalaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoBalaApplication.class, args);
	}

}
